(async () => {
    const express = require('express');
    const cors = require('cors');
    const db = require('./database');

    const app = express();
    const PORT = 1234;

    app.use(cors());
    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));

    //Mostra os users no cmd ao iniciar server

    const listaUsers = await db.selectUsers();
    console.log('Users da BD:');
    console.log(listaUsers);


    app.get('/users', async (req, res) => {
    try{
        const users = await db.selectUsers();
        res.json(users);
    }catch(err){
        console.error(err);
        res.status(500).json({ error: 'Erro ao obter users.' });
    }
    });

    app.post('/user', async (req, res) => {
        const { nome, email, idade } = req.body;
        try {
            await db.insertUser(nome, email, idade);
            res.json({ success: true });
        } catch (err) {
            console.error(err);
            res.status(500).json({ error: 'Erro ao inserir user.' });
        }
    });

    app.put('/user/:id', async (req, res) => {
        const userId = parseInt(req.params.id);
        const { nome, email, idade } = req.body;

        try{
            await db.updateUser(userId, nome, email, idade);
            res.json({ success: true });
        }catch(err){
            console.error(err);
            res.status(500).json({ error: 'Erro ao atualizar user.' });
        }
    });

    app.delete('/user/:id', async (req, res) => {
        const userId = parseInt(req.params.id);
        try{
            await db.deleteUser(userId);
            res.json({ success: true });
        }catch(err){
            console.error(err);
            res.status(500).json({ error: 'Erro ao eliminar user.' });
        }
    });

    app.listen(PORT, () => {
    console.log(`Server ON em http://localhost:${PORT}`);
    });
})();
