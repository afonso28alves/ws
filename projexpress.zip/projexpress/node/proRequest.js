var http = require('http'); 
const express = require('express');
const app = express();

var criarProcessRequest = function(port){
	var entrada = {};
	var caminhos = {};
	var metodos = ['GET','POST','PUT','DELETE'];

	metodos.forEach(function(metodo){
		caminhos[metodo] = {};
		entrada[metodo.toLowerCase()] = function(path,fn){
			caminhos[metodo][path] = fn;
		};
	});

	http.createServer(function(req,res){
		res.setHeader('Access-Control-Allow-Origin','*');
		if(!caminhos[req.method][req.url]){
			res.statusCode = 404;
			return res.end();
		}
		caminhos[req.method][req.url](req,res);
	}).listen(port);

	return entrada;
};

module.exports = criarProcessRequest;
