async function connect(){
    if(global.connection && global.connection.state !== 'disconnected')
        return global.connection;
    const mysql = require("mysql2/promise");
    /*
    mysql2 -> createConnection() -> ligação a BD, este metodo é assincrono,
    como tal callback que transforma a nossa funcao sync/wait, deste modo
    a operaçao apenas executa apos criação da ligação
    */
   const connection = await mysql.createConnection("mysql://root@localhost:3306/webservice_prog23");
    console.log("Server ON, port:3306");
    global.connection = connection;
    return global.connection;
}

async function selectUsers(){
    const conn = await connect();
    //query -> devolve um array com varias porps., no entanto a unica importante é a prop. rows(a consulta em si)
    
    const [rows] = await conn.query('SELECT * FROM user'); 
    return rows;
}

async function insertUser(nome, email, idade) {
  const conn = await connect();
  const sql = 'INSERT INTO user (nome, email, idade) VALUES (?, ?, ?)';
  const values = [nome, email, idade];
  return await conn.query(sql, values);
}

async function deleteUser(userId){
    const conn = await connect();
    return await conn.query('DELETE FROM user WHERE id = ?', [userId]);
}

async function updateUser(id, nome, email, idade) {
  const conn = await connect();
  const sql = 'UPDATE user SET nome = ?, email = ?, idade = ? WHERE id = ?';
  const values = [nome, email, idade, id];
  return conn.query(sql, values);
}


module.exports = { selectUsers, insertUser, deleteUser, updateUser };


