<!DOCTYPE html>
<html>
	<head>
	<meta charset="UTF-8">
	<title>Users</title>
	</head>
	<body>
		<h1>Gestão de Users</h1>

		<form id="userForm">
			<input type="hidden" id="userId">
			<label>Nome:</label><br>
			<input type="text" id="nome" required><br>
			<label>Email:</label><br>
			<input type="email" id="email" required><br>
			<label>Idade:</label><br>
			<input type="text" id="idade" required><br>
			<input type="submit" value="Guardar">
		</form>

		<h2>Lista de Users</h2>
		<table border="1">
			<thead>
			<tr>
				<th>Nome</th>
				<th>Email</th>
				<th>Idade</th>
				<th>Ações</th>
			</tr>
			</thead>
			<tbody></tbody>
		</table>

		<script>
			async function carregarUsers() {
				const res = await fetch('http://localhost:1234/users');
				const users = await res.json();
				const tbody = document.querySelector('tbody');
				tbody.innerHTML = '';
				users.forEach(u => {
					const tr = document.createElement('tr');
					tr.innerHTML = `
					<td>${u.nome}</td>
					<td>${u.email}</td>
					<td>${u.idade}</td>
					<td>
						<button onclick="editarUser(${u.id}, '${u.nome}', '${u.email}', ${u.idade})">Editar</button>
						<button onclick="eliminarUser(${u.id})">Eliminar</button>
					</td>
					`;
					tbody.appendChild(tr);
				});
			}

			async function eliminarUser(id) {
				await fetch(`http://localhost:1234/user/${id}`, { method: 'DELETE' });
				carregarUsers();
			}

			// Preenche o formulário com os dados do utilizador clicado
			function editarUser(id, nome, email, idade) {
				document.getElementById('userId').value = id;
				document.getElementById('nome').value = nome;
				document.getElementById('email').value = email;
				document.getElementById('idade').value = idade;
			}

			document.getElementById('userForm').addEventListener('submit', async (e) => {
				e.preventDefault();

				const id = document.getElementById('userId').value;
				const nome = document.getElementById('nome').value;
				const email = document.getElementById('email').value;
				const idade = document.getElementById('idade').value;

				if (id) {
					// Atualizar user existente
					await fetch(`http://localhost:1234/user/${id}`, {
					method: 'PUT',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ nome, email, idade })
					});
				} else {
					// Inserir novo user
					await fetch('http://localhost:1234/user', {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ nome, email, idade })
					});
				}

				// Limpa formulário e atualiza lista
				e.target.reset();
				document.getElementById('userId').value = '';
				carregarUsers();
			});

			window.onload = carregarUsers;
		</script>
	</body>
</html>
