<?
require_once '../ws_config.php';
// por tudo dentro de uma funcao e chamar os parametros no form
	//CURL 
function inserir($nome, $email, $idade){	
	$ci = curl_init();
	curl_setopt($ci, CURLOPT_URL, "http://localhost/3ano/AfonsoAlvesws/projnode/user");
	curl_setopt($ci, CURLOPT_POST, true);
	curl_setopt($ci, CURLOPT_POSTFIELDS, 
		array(
			'nome' => $nome,
			'email' => $email,
			'idade' => $idade
		)
	);
	curl_setopt($ci, CURLOPT_HEADER, false);
	curl_setopt($ci, CURLOPT_RETURNTRANSFER, 1);

	$response = curl_exec($ci);
	curl_close($ci);
}

?>