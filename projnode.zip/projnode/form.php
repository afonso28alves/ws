<?
require_once "request.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$nome = $_POST['nome'] ?? '';
	$email = $_POST['email'] ?? '';
	$idade = $_POST['idade'] ?? '';
	inserir($nome, $email, $idade);
}

?>

<!DOCTYPE html>
<html lang="pt">
	<head>
		<meta charset="UTF-8">
		<title>Adição de users</title>
	</head>
	<body>
		<h2>Inserir User</h2>
		<form method="POST">
			<label>Nome:</label><br>
			<input type="text" name="nome" required><br><br>

			<label>Email:</label><br>
			<input type="email" name="email" required><br><br>

			<label>Idade:</label><br>
			<input type="text" name="idade" required><br><br>

			<input type="submit" value="Enviar">
		</form>
	</body>
</html>
