(async () => {
    const db = require('./database');
    const listaUsers = await db.selectUsers();
    console.log(listaUsers);

    const serverRequest = require('./proRequest');
    const aplicacao = serverRequest(1234);

    //Browser: localhost:1234/users
    aplicacao.get('/users', function(req, res){
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify(listaUsers));

    });

    console.log("Server on em http://localhost:1234/users");

})();